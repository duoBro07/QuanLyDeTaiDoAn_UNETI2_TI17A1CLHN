﻿(function () {
    "use strict";

    document.addEventListener("DOMContentLoaded", function () {

        const modalElement = document.getElementById(
            "modalXacNhanChung"
        );

        const noiDung = document.getElementById(
            "noiDungXacNhanChung"
        );

        const btnDongY = document.getElementById(
            "btnDongYXacNhanChung"
        );

        // Kiểm tra thành phần cần thiết
        if (!modalElement || !noiDung || !btnDongY) {
            console.error("Không tìm thấy modal xác nhận chung.");
            return;
        }

        // Kiểm tra Bootstrap
        if (typeof bootstrap === "undefined") {
            console.error("Bootstrap chưa được tải.");
            return;
        }

        const modal = bootstrap.Modal.getOrCreateInstance(
            modalElement
        );

        let formChoXacNhan = null;
        let nutGuiForm = null;
        let dangXuLy = false;

        // =========================================
        // CHUYỂN TIẾNG VIỆT CÓ DẤU THÀNH KHÔNG DẤU
        // =========================================

        function boDau(chuoi) {
            return chuoi
                .toLowerCase()
                .normalize("NFD")
                .replace(/[\u0300-\u036f]/g, "")
                .replace(/đ/g, "d")
                .trim();
        }

        // =========================================
        // NHẬN DIỆN NỘI DUNG XÁC NHẬN
        // =========================================

        function layNoiDungXacNhan(form, submitter) {

            // Cho phép từng form tùy chỉnh nội dung
            if (form.dataset.confirmMessage) {
                return form.dataset.confirmMessage;
            }

            const action = boDau(
                (submitter?.formAction || form.action || "") +
                " " +
                (submitter?.textContent || submitter?.value || "")
            );

            if (/dangxuat|logout/.test(action)) {
                return "Bạn có chắc chắn muốn đăng xuất khỏi hệ thống không?";
            }

            if (/xoa|delete|remove/.test(action)) {
                return "Bạn có chắc chắn muốn xóa dữ liệu này không?";
            }

            if (/tuchoi|reject/.test(action)) {
                return "Bạn có chắc chắn muốn từ chối yêu cầu này không?";
            }

            if (/duyet|approve/.test(action)) {
                return "Bạn có chắc chắn muốn duyệt yêu cầu này không?";
            }

            if (/huy|cancel/.test(action)) {
                return "Bạn có chắc chắn muốn hủy thao tác này không?";
            }

            if (/them|create|add/.test(action)) {
                return "Bạn có chắc chắn muốn thêm dữ liệu này không?";
            }

            if (/sua|edit|update|capnhat/.test(action)) {
                return "Bạn có chắc chắn muốn cập nhật dữ liệu này không?";
            }

            if (/phancong/.test(action)) {
                return "Bạn có chắc chắn muốn lưu thông tin phân công này không?";
            }

            return "Bạn có chắc chắn muốn thực hiện thao tác này không?";
        }

        // =========================================
        // BẮT SỰ KIỆN SUBMIT TOÀN HỆ THỐNG
        // =========================================

        document.addEventListener("submit", function (event) {

            const form = event.target;

            if (!(form instanceof HTMLFormElement)) {
                return;
            }

            const submitter = event.submitter;

            const method = (
                submitter?.formMethod ||
                form.method ||
                "get"
            ).toLowerCase();

            // Chỉ xác nhận form POST
            if (method !== "post") {
                return;
            }

            // Cho phép bỏ qua xác nhận nếu cần
            if (form.dataset.confirm === "false") {
                return;
            }

            // Form đã được xác nhận trước đó
            if (form.dataset.unetiConfirmed === "1") {
                delete form.dataset.unetiConfirmed;
                return;
            }

            // Chặn gửi form lần đầu
            event.preventDefault();

            if (dangXuLy) {
                return;
            }

            formChoXacNhan = form;
            nutGuiForm = submitter || null;

            // Hiển thị nội dung
            noiDung.textContent = layNoiDungXacNhan(
                form,
                nutGuiForm
            );

            // Mở modal
            modal.show();

        }, true);

        // =========================================
        // NGƯỜI DÙNG BẤM ĐỒNG Ý
        // =========================================

        btnDongY.addEventListener("click", function () {

            if (!formChoXacNhan || dangXuLy) {
                return;
            }

            const form = formChoXacNhan;
            const submitter = nutGuiForm;

            dangXuLy = true;
            btnDongY.disabled = true;

            // Xóa dữ liệu đang chờ
            formChoXacNhan = null;
            nutGuiForm = null;

            // Đánh dấu form đã được xác nhận
            form.dataset.unetiConfirmed = "1";

            // Đóng modal
            modal.hide();

            // Gửi lại đúng form
            if (
                submitter &&
                submitter.form === form &&
                !submitter.disabled
            ) {
                form.requestSubmit(submitter);
            } else {
                form.requestSubmit();
            }

            // Mở lại trạng thái nút nếu trang không chuyển
            window.setTimeout(function () {
                dangXuLy = false;
                btnDongY.disabled = false;
            }, 1000);

        });

        // =========================================
        // NGƯỜI DÙNG HỦY / ĐÓNG MODAL
        // =========================================

        modalElement.addEventListener(
            "hidden.bs.modal",
            function () {

                formChoXacNhan = null;
                nutGuiForm = null;

                dangXuLy = false;
                btnDongY.disabled = false;

            }
        );

    });

})();